export const firebaseConfig = {
  "projectId": "studio-6092829349-6ea05",
  "appId": "1:837793206580:web:30f01aa3841a1309b15561",
  "apiKey": "AIzaSyAqWvuo5GFJZHELM9O5dMplLjWIB66IVvM",
  "authDomain": "studio-6092829349-6ea05.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "837793206580"
};
